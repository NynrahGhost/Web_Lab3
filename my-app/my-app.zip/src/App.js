import React from "react";
import './index.css'
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";


export default function App() {
  return (
    <Router>
      <div>
        <nav>
          <ul>
            <li>
              <Link to="/recipes">Recipes</Link>
            </li>
            <li>
              <Link to="/add">Add</Link>
            </li>
			<li>
              <Link to="/edit">Edit</Link>
            </li>
          </ul>
        </nav>

        {/* A <Switch> looks through its children <Route>s and
            renders the first one that matches the current URL. */}
        <Switch>
		  <Route path="/recipes/:recipeId" component={RecipeId} />
		  <Route path="/recipes">
            <Recipes />
          </Route>
          <Route path="/add">
            <Add />
          </Route>
		  <Route path="/edit/">
            <Edit />
          </Route>
          <Route exact path="/">
            <Recipes />
          </Route>
        </Switch>
      </div>
    </Router>
  );
}

function componentDidMount() {
    let url = "http://localhost:3001/recipes"
    fetch(url)
      .then(resp => resp.json())
      .then(data => {
        let posts = data.map((post, index) => {
          return (

            <div key={index}>
              <h3>{post.title}</h3>
              <p>Tags: {post.tags}</p>
            </div>

          )
        })
        this.setState({posts: posts});
      })
}

function Recipes() {
  let res = [];
  let recipes = JSON.parse(httpGet("http://localhost:3001/recipes"));
  console.log(recipes);
  for (let i = 0; i < recipes.length; i++) {
    res.push(
	<div class="recipe" onClick={event =>  window.location.href='http://localhost:3000/recipes/'+i}>
		<div class="clearfix">
			<img align="left" height="64" width="64" src="https://image.flaticon.com/icons/png/512/100/100417.png" />
			<b>{ recipes[i].name }</b><br/>
			<i>{ recipes[i].shortDesc }</i>
			<div class="clear"/>
		</div>
	</div>)
  }
  
  return (<div>{ res }</div>);
}

function RecipeId({ match }) {
	let recipe = JSON.parse(httpGet("http://localhost:3001/recipes/"+match.params.recipeId));
	let res = 
	<div class="recipe">
		<div class="clearfix">
		<img align="left" height="64" width="64" src="https://image.flaticon.com/icons/png/512/100/100417.png" />
		<b>{ recipe.name }</b><br/>
		<i>{ recipe.shortDesc }</i>
		<div class="clear"/>
		</div>
	</div>
	return res;
}

function Add() {
  let res = 
  <form onsubmit="httpPost('http://localhost:3001/recipes');">
	<p>
	  <b>Назва рецепту:</b> <br/>
	  <input id="name" required type="text" placeholder="Назва рецепту" /> <br/>
	  <b>Категорія:</b> <br/>
	  <select id="category">
		<option>1</option>
		<option>2</option>
		<option>3</option>
	  </select> <br/> 
	  <b>Опис:</b> <br/>
	  <textarea id="shortDesc" cols="40" rows="3"/> <br/>
	  <b>Рецепт:</b> <br/>
	  <textarea id="longDesc" cols="40" rows="10"/> <br/>
	  <input type="submit" value="Додати"/>
	</p>
  </form>
	
  return res;
}

function Edit() {
  return <h2>Edit</h2>;
}

function httpGet(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "GET", theUrl, false ); // false for synchronous request
    xmlHttp.send( null );
    return xmlHttp.responseText;
}

function httpPost(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "POST", theUrl, false ); // false for synchronous request
	
	var today = new Date();
	
	var obj = {
      "id": 3,
      "name": document.getElementById("name"),
      "category": document.getElementById("category"),
	  "shortDesc": document.getElementById("shortDesc"),
	  "longDesc": document.getElementById("longDesc"),
	  "createDate": today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate()
    }
    xmlHttp.send( obj );
    return xmlHttp.responseText;
}